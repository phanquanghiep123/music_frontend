export class Service {
    status: boolean = false;
    message: string = "";
    response: any = null;
    limit : number = 0;
    page  : number = 0;
    total : number = 0;
    public_url : string;
    redirect : boolean = false;
    
}