export class Currency {
    id: number = 0;
    name: string = "";
    value: string = ""; description: string = '';
    icon: string = "";
    price: number = 0
}
