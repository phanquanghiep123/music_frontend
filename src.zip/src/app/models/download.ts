export class Download {
    artist_id;
    checkout_id;
    created_at;
    diffTime;
    end;
    id;
    number_dowload;
    payment_id;
    public_key;
    start;
    status;
    updated_at;
}