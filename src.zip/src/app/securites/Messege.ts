export class Messege {
    email : 'incorrect formatting';
    required : 'is required';
    number   : 'is number';
    date     : 'is the date and time';
}