export const Config  = {
    APIURL  : "http://remyx.in/getdata/api/frontend/",
    MAIL    : "phanquanghiep123@gmail.com",
    APIKEY  : "ram",
    BASEURL : "http://remyx.in"
};